# kaeru vault

Exported: 2026-07-13 13:12:15 UTC
Scope: initiative `lamantin-ai`
Nodes: 4
Edges: 4
Audit events: 8

This is a derived snapshot of a kaeru substrate. The substrate stays
authoritative — re-run `kaeru export` to refresh.

Layout:
- Pages live under `<tier>/<type>/<sanitized-name>.md`.
- Each page has YAML frontmatter (id, type, tier, layer, initiatives,
  tags), a body, and optional `## Outgoing` / `## Incoming` sections of
  `[[wikilink]]` references grouped by edge type.

See [[INDEX]] for navigation across every exported page, and [[LOG]]
for the chronological audit-event stream of operations on visible
nodes.
