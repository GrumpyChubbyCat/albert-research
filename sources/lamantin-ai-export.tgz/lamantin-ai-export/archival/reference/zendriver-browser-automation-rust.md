---
id: 019f5b5f-c11d-7650-a031-e8174cc2365f
type: reference
tier: archival
layer: warm
initiatives:
  - lamantin-ai
tags:
  - kind:reference
  - lang:en
  - topic:stealth
  - topic:website-parsing
  - topic:browser-automation
  - topic:library
  - topic:rust
---

# Zendriver — browser automation (Rust)

Stealth website-parsing / browser-automation library in Rust (also exists as a Claude plugin). Candidate for teaching Albert to browse the web — likely wired into Octo as a browser connector on top of Forkd.

## Outgoing

### derived_from

- [[forkd-octo-execution-layer]]

