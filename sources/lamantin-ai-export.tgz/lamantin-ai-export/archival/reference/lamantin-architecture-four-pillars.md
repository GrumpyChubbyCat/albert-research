---
id: 019f5b5f-b582-7613-bbf7-089cfbad0b72
type: reference
tier: archival
layer: warm
initiatives:
  - lamantin-ai
tags:
  - kind:reference
  - lang:en
  - topic:architectural
  - topic:requirements
  - topic:lamantin
  - topic:four
  - topic:pillars
---

# Lamantin architecture — four pillars

Architectural requirements for Lamantin. Four pillars: (1) SQLite per channel; (2) secure multitenancy enforced at the router; (3) per-user data isolation; (4) access checks performed by the router itself (the router is the authority on who may reach what).

## Incoming

### part_of

- [[forkd-octo-execution-layer]]

### refers_to

- [[isolation-forkd-sandboxing-architecture]]

