---
id: 019f5b86-2970-7e71-b7a6-fe8a12c39525
type: reference
tier: archival
layer: warm
initiatives:
  - lamantin-ai
tags:
  - kind:reference
  - lang:en
  - topic:design
  - topic:conclusions
  - topic:sandboxing
  - topic:albert
  - topic:octo
---

# Isolation & forkd — sandboxing architecture

Design conclusions on sandboxing Albert (the Octo cogitator) and its scripts.

TWO DISTINCT SANDBOXES — don't conflate:
- Agent-sandbox: protects the HOST from the agent (and from anything that compromises it).
- forkd / script-sandbox: protects the AGENT from the code it runs (untrusted scripts).

forkd — CONNECTOR, not an in-process tool. Its whole value is isolation + supervision + a fault boundary; running scripts as an in-process rig tool would let a hung/rogue script wedge the cogitator's tool-loop. So forkd is a supervised Octo connector: cogitator dispatches `forkd.run` -> it runs the script in a sandbox in its own task -> returns `forkd.result`. The LLM reaches it via the existing `dispatch_to_connector` (a dedicated `run_script` tool would just be sugar over that). Contrast kaeru/scratchpad, which ARE in-process tools — correct because they're local & trusted, no isolation needed. forkd differs precisely because it runs untrusted code.
- Substrate vs door: the sandbox mechanism (bwrap/nsjail + drop-privs + cwd logic) is a LIBRARY (this is "forkd the lowest execution layer, not a connector" from the original note). It is wrapped AS a connector so Octo can call & supervise it. Both true, different layers.
- bwrap itself is neither connector nor tool — it's the mechanism the sandbox uses.
- MVP shortcut: start with an in-process `run_script` tool, promote to a connector later; same LLM-facing contract.

Scripts are python/bash = real interpreter processes -> substrate must be subprocess + Linux sandbox (bwrap/nsjail/landlock/seccomp/cgroups), NOT WASM.

THREE ISOLATION LAYERS — defense in depth, complementary (none replaces another):
- L1 infra (host <- agent): systemd-hardening OR a container (Docker/podman).
- L2 code/scripts (agent <- the scripts it runs): forkd -> bwrap. v0 = drop-uid + cwd=scratch-dir + /tmp (this is exactly the "/tmp or own folder" the home agent proposed — forkd v0, not a competitor to forkd).
- L3 per-skill capabilities (script <- resources): net/fs_rw/timeout/mem, declared per skill (forkd.toml), forkd grants the minimum & the sandbox enforces. Ties to the Lamantin four-pillars "access checking by the router" — forkd is the router for code.

KEY POINT: L1 does NOT replace L2. A container confines the agent from the host, but a script running inside can still trash the agent's own kaeru vault -> code-level isolation (L2) is needed even in Docker.

DEPLOY CONTEXT (nl-vmnano): Albert runs as a ROOT systemd service on the bare host, no container. Two options for L1:
- Harden the systemd unit (systemd IS the sandbox you already have): User= (drop root — main win), NoNewPrivileges, ProtectSystem=strict, ProtectHome, PrivateTmp, ReadWritePaths=/opt/albert/{state,kaeru}, RestrictNamespaces, RestrictAddressFamilies, SystemCallFilter=@system-service, CapabilityBoundingSet=. Need to chown state/ & kaeru/ to the new user. ~80% of the safety for ~20% effort, no image pipeline.
- Containerize (no systemd inside -> the container IS the boundary): non-root USER, --read-only rootfs, --cap-drop=ALL, no-new-privileges, no --privileged, never mount docker.sock or sensitive host paths; kaeru+state as named volumes (backed up); .env via secret. Orchestration can still be a systemd unit running `podman run`. Cleaner/more portable, but adds build->image->run.
Note: "shouldn't break its own container" has two meanings — (a) escape to host = prevented by proper container config; (b) corrupt its OWN data = NOT prevented by the container (needs read-only code mount + backed-up data volume).

Nested-sandbox caveat for later: bwrap/user-namespaces INSIDE an unprivileged container is fiddly (needs nested userns, e.g. rootless podman, or run scripts in a sibling ephemeral container).

## Outgoing

### refers_to

- [[forkd-octo-execution-layer]]
- [[lamantin-architecture-four-pillars]]

