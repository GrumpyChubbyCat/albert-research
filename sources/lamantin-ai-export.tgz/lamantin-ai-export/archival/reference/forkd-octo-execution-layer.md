---
id: 019f5b5f-bb70-7100-8df2-1434e3cc4ea8
type: reference
tier: archival
layer: warm
initiatives:
  - lamantin-ai
tags:
  - kind:reference
  - lang:en
  - topic:forkd
  - topic:connector
  - topic:octos
  - topic:lowest
  - topic:execution
---

# Forkd — Octo execution layer

Forkd is NOT a connector but Octo's lowest execution layer — a safe/sandboxed runtime for running scripts. Sits beneath the connector layer as the substrate that actually executes code.

## Outgoing

### part_of

- [[lamantin-architecture-four-pillars]]

## Incoming

### derived_from

- [[zendriver-browser-automation-rust]]

### refers_to

- [[isolation-forkd-sandboxing-architecture]]

